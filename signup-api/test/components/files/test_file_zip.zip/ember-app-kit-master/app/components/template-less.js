export default Ember.Component.extend({
  classNames: ['look-ma-no-template'],
  tagName: ['span']
});
