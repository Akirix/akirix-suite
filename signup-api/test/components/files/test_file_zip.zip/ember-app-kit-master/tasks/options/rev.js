module.exports = {
  dist: {
    files: {
      src: [
        'dist/assets/config.min.js',
        'dist/assets/app.min.js',
        'dist/assets/vendor.min.js',
        'dist/assets/app.min.css'
      ]
    }
  }
};
