module.exports = {
  html: 'tmp/result/index.html',
  options: {
    dest: 'dist/'
  }
};
