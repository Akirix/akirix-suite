// Put your test configuration here.
//
// This is useful when using a separate API
// endpoint in test than in production.
//
// window.ENV.public_key = '123456'
